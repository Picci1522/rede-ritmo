# Assets da página — 14/11/2026

| Arquivo | Uso | Origem |
|---|---|---|
| `orbita-horizontal-verde-v1.svg` | Marca no topo | Construção vetorial original por código; texto Inter em curvas |
| `orbita-simbolo-verde-v1.svg` | Favicon | Mesma construção geométrica da órbita/satélite |
| `hero-equipe-v1.webp` | Hero | image_gen integrada; Joca com dois colegas, a partir do retrato-base |
| `diagnostico-v1.webp` | Formulário | image_gen integrada; Joca conversando com cliente fictícia |

Orbita Labs e pessoas são fictícias. Não se afirma semelhança com pessoas reais. Aparência do personagem é proposta executada, sem aceite visual humano registrado. Sem imagens de banco ou marcas reais.

Originais PNG, marca em SVG editável/curvas e PNG transparente, retrato, recorte v2 e cena de apresentação estão no [kit visual](../../assets/kit-visual/index.html). A v1 do recorte foi preservada.

WebP 1200×900, qualidade 88: hero 136876 bytes; diagnóstico 136182 bytes. Conversão com Pillow, originais preservados. [Prompts exatos e referências](../../assets/kit-visual/prompts.md).

Inter vem do [Google Fonts](https://github.com/google/fonts/tree/main/ofl/inter), sob SIL Open Font License; arquivo e licença em `../fonts/`. A identidade SCTEC veio do kit local fornecido; nenhuma assinatura institucional foi reproduzida ou alterada.
