// Orbita Labs · envio do formulário da campanha para o fluxo de automação (webhook).
// Parâmetros de URL:
//   ?etapa=1        mostra só o campo nome (aula 1)
//   ?webhook=LINK   link do webhook (Test URL ou Production URL)
//   ?formato=json   envia como JSON (o padrão é formulário, que evita a consulta prévia de CORS)
(function () {
  "use strict";

  var params = new URLSearchParams(window.location.search);
  var etapa = params.get("etapa") === "1" ? 1 : 2;
  var formato = params.get("formato") === "json" ? "json" : "form";

  var form = document.getElementById("form-diagnostico");
  var status = document.getElementById("status");
  var campoWebhook = document.getElementById("webhook");
  var botao = form.querySelector('button[type="submit"]');

  // Mostra só os campos da etapa
  if (etapa === 1) {
    form.querySelectorAll('[data-etapa="2"]').forEach(function (el) {
      el.classList.add("oculto");
    });
  }

  // Link do webhook: primeiro o da URL, depois o salvo nesta aba
  var webhookDaUrl = params.get("webhook");
  try {
    campoWebhook.value = webhookDaUrl || sessionStorage.getItem("webhook") || "";
  } catch (e) {
    campoWebhook.value = webhookDaUrl || "";
  }
  campoWebhook.addEventListener("change", function () {
    try { sessionStorage.setItem("webhook", campoWebhook.value.trim()); } catch (e) { /* sem armazenamento */ }
  });

  function mostrar(texto, tipo) {
    status.textContent = texto;
    status.className = "status" + (tipo ? " status--" + tipo : "");
  }

  function marcar(id, invalido) {
    var el = document.getElementById(id);
    if (el) el.closest(".campo").classList.toggle("invalido", invalido);
  }

  function coletar() {
    var dados = { nome: form.nome.value.trim() };
    if (etapa === 2) {
      dados.email = form.email.value.trim();
      dados.whatsapp = form.whatsapp.value.trim();
      dados.empresa = form.empresa.value.trim();
      dados.porte = form.porte.value;
      dados.area = form.area.value;
      dados.prazo = form.prazo.value;
      dados.consentimento = form.consentimento.checked ? "sim" : "nao";
    }
    dados.site = form.site.value; // isca: deve ir vazio
    return dados;
  }

  // Validação básica no navegador. A validação de verdade fica no fluxo (aula 5).
  function validar(dados) {
    var erros = [];
    marcar("nome", false); marcar("email", false);
    if (dados.nome.length < 2) { erros.push("Digite o seu nome."); marcar("nome", true); }
    if (etapa === 2 && dados.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(dados.email)) {
      erros.push("Confira o e-mail."); marcar("email", true);
    }
    return erros;
  }

  function montarEnvio(dados) {
    if (formato === "json") {
      return { headers: { "Content-Type": "application/json" }, body: JSON.stringify(dados) };
    }
    return { body: new URLSearchParams(dados) }; // application/x-www-form-urlencoded
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();
    var dados = coletar();
    var erros = validar(dados);
    if (erros.length) { mostrar(erros.join(" "), "erro"); return; }

    var link = campoWebhook.value.trim();
    if (!link) {
      mostrar("Falta o endereço que recebe os pedidos. Abra a Configuração no rodapé e cole o link do webhook.", "erro");
      document.querySelector(".config").open = true;
      campoWebhook.focus();
      return;
    }

    var envio = montarEnvio(dados);
    botao.disabled = true;
    mostrar("Enviando…");

    fetch(link, { method: "POST", headers: envio.headers, body: envio.body })
      .then(function (resposta) {
        return resposta.text().then(function (texto) {
          if (!resposta.ok) {
            var dica = resposta.status === 404
              ? " O endereço de teste escuta só por 120 segundos. Clique de novo em Execute workflow."
              : "";
            throw new Error("O fluxo respondeu " + resposta.status + "." + dica);
          }
          return texto;
        });
      })
      .then(function (texto) {
        var mensagem = texto;
        try {
          var json = JSON.parse(texto);
          mensagem = json.mensagem || json.message || texto;
        } catch (e) { /* resposta em texto */ }
        mostrar(mensagem || "Enviado!", "ok");
        form.reset();
      })
      .catch(function (erro) {
        var texto = erro instanceof TypeError
          ? "Não deu para falar com o fluxo. Confira o link e, se estiver usando ?formato=json, veja o console (pode ser CORS)."
          : erro.message;
        mostrar(texto, "erro");
      })
      .finally(function () { botao.disabled = false; });
  });
})();
